<?php
	include('functions.php');

	$act = strip_tags($_GET['act']);
	if(empty($act)){ header('location:'.site_dir.'/data/'); }
	
	if($act == 'logout')
	{  
		$_SESSION['hash'] = '0';
		$_SESSION['login'] = '0';
		$_SESSION['user_id'] = '-1';
		header('location: http://'.$_SERVER['SERVER_NAME'].site_dir.'/login.php');

	}
	
	if(!change_auth($login,$hash))
	{ 
		header('location: http://'.$_SERVER['SERVER_NAME'].site_dir.'/login.php');
	}	
	
	include('pages/head.php');

?>
<body>
	<div id='main'>
		<input type='hidden' id='site_' value='<?=site_dir;?>'>
		<input type='hidden' id='self' value='<?=$act;?>'>
		<div class='panel'>
			<? include('pages/header.php'); ?>
		
			<div class='content'>
			<?
				if(!empty($act))
				{
					$in = 'pages/a_'.$act.'.php';
					include($in);
				}
		
			?>	
			
			</div>
			
<?
	include('pages/footer.php');
?>
	
		</div>	
	</div>

</body>	
	
</html>