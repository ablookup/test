﻿	
	<footer>
		<span title='Текущий IP'>IP: <?=$_SERVER['REMOTE_ADDR']?></span><br>

		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script src='<?=site_dir;?>/js/func.js'></script>
	
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		<?if(stristr('info',$act)){?>
		<script>
		  $( function() {
			$( "#add_news_" ).dialog({
			  autoOpen: false,
			  height: 450,
			  width: 350,
			  modal: true,
			} );
		  } );
		  </script>	
		<?}?>
			<script>
			  $( function() {
				$( document ).tooltip({
				  track: true
				});
			  } );
			  
			  
			   $( function(){
					$( "#info_ip" ).dialog({
					  autoOpen: false,
					  height: 290,
					  width: 370,
					  modal: false,
					} );
			  });
  </script>
	
  
		  
	<div class='change_pwd'>
			<div class='title'>Смена пароля
				<span id='close_ch'>X</div>

			<div class='text'>
				<label>Введите текущий пароль</label>
				<input type='password' name='pass_old' id='pass_old'>
				
				<label>Введите новый пароль</label>
				<input type='password' name='pass_new' id='pass_new' style='margin-bottom:12px;'>

				<label>Повторите новый пароль</label>
				<input type='password' name='pass_new1' id='pass_new1'>		

				
				<span id='stat' class='info_ch'></span>		
				<button class="btn_red chang_pass_go"><i class="fa fa-floppy-o" aria-hidden="true"></i> Сменить</button>	
					
			</div>
	</div>

		<?if(stristr('info',$act)){?>	
		<div id="add_news_"  title="Добавление записи" >
		  <p>
			<form id='data_f' onsubmit='return false'><br>
			<input type='hidden' name='act' value='news_add'>
				<label style='display: block;padding-bottom: 6px;'>Заголовок</label>
				<input type='text' name='title' style='padding: 2px 4px;width:98%;'><br><br>
				
				<label style='display: block;'>Текст</label><br>
				<textarea name='text' style='width:100%;height:198px;'></textarea>
				
				<button class="btn_red add_news_item"><i class="fa fa-floppy-o" aria-hidden="true"></i> Добавить</button>	
				<br><b id='news_stat'>Добавлено!</b>
			</form>
		  </p>
		</div>	
		<?}?>
		
		
		



		<div id="info_ip"  title="Информация IP" >
		  <p>
			
				<label style=';'>Текст</label><br>
			
				<div class='info_ip'></div>
			
			
		  </p>
		</div>						
		
	</footer>