	<div id='header'>
		<div style='width:19%;' id='logo'>
			<span ><a style='font-size:16px;' href='<?=site_dir;?>/data/'>Stealer[ANTI-VIDAR]</a></span> 
		</div>
		
		<div>
			<ul class='menu'>
				<li><a href='<?=site_dir;?>/data/' title='Данные'><i class="fa fa-bars" aria-hidden="true"></i> Данные</a></li>
				<li><a href='<?=site_dir;?>/logs/' title='Смотреть логи'><i class="fa fa-list-alt" aria-hidden="true"></i> Логи</a></li>
				
				<li><a href='<?=site_dir;?>/info/' title='Информация'><i class="fa fa-info-circle" aria-hidden="true"></i> Info</a></li>
			</ul>
		</div>	
		
		
		<div style='width:221px;'>
			<ul class='menu_s' >
				<li><a href='#' id='change_pass' title='Сменить пароль аккаунта'><i class="fa fa-exchange" aria-hidden="true"></i> Сменить пароль</a></li>
				<li><a href='<?=site_dir;?>/logout/' title='Завершить сессию ?'><i class="fa fa-reply-all" aria-hidden="true" ></i> Выход</a></li>
			</ul>
		</div>		
			
	</div>