<style>
	.title{font-size: 15px;}
</style>

<div class='info'>
		<h2>Информация</h2>
	</div>
	
	<div class='information'>

		<div class='scroll_'>
		<h1>Описание</h1>
			<div class='item i1' >
					<span class='title'>AVE SATAN<br>
					<b>XXXXXXXX</b> - Стиллер паролей.</span><br><br>
					
					<span class='title'>Cracked XakFor.net
					<span class='desc'><a target='_blank' style='color:#FFEB3B;' href='https://xakfor.net/forum/'>Forum</a></span>
					</span> 
					<span class='title'>XakFor.net AV Telegram Scanner
					<span class='desc'><a target='_blank' style='color:#FFEB3B;' href='https://t.me/xakfor_scanner_bot'>Telegram Scanner</a></span>
					</span>
					
					
			</div>		
		
			
		
	</div>
	</div>