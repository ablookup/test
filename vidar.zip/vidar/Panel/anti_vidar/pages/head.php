<!DOCTYPE html>
<html>
	<head>
	<meta charset='UTF-8' />
	<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes" />	
	<meta name="format-detection" content="telephone=no" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="MobileOptimized" content="176" />
	<meta NAME="Author" CONTENT="suicide_vll"> 
	
	<link href="<?=site_dir;?>/css/reset.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="<?=site_dir;?>/css/style.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="<?=site_dir;?>/css/font-awesome.css" media="screen" rel="stylesheet" type="text/css" />
	
	</head>