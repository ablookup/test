	
	<div class='info'>
		<h2>Данные</h2>
	</div><br>

<?
	$api = get_colomn_val('data','version_api','1');
	$coder = get_colomn_val('data','coder','1');
	$code = get_colomn_val('data','service_info','1');
	
		$r = mysqli_query($db,"SELECT `id` FROM `logs`");
		$logs = mysqli_num_rows($r);
		

?>	 
	
			<table border='1' style='margin-top: -15px;'>
			<tr>
				<td class='td_r'>Пользователь</td>
				<td><b><?=$login;?></b></td>
			</tr>
			
			<tr>
				<td class='td_r'>Кол-во логов</td>
				<td><a href='<?=site_dir;?>/logs/' ><?=$logs;?></a></td>
			</tr>	
			
	
			<tr>
				<td class='td_r'>Лицензионное соглашение</td>
				<td>xakfor</td>
			</tr>

		
		

			<tr>
				<td class='td_r'>Разработчик</td>
				<td>Xakfor.net</td>
			</tr>	

						
			</table>