<?php
	session_start();
	
	DEFINE('login','LOGIN'); 
	DEFINE('pass','PASSWORD_');
	DEFINE('host','localhost');
	DEFINE('base','BASE'); 
	DEFINE('site_dir','/anti_vidar');
	
	$db = mysqli_connect(host,login,pass,base) or die(mysqli_error($db));
 	mysqli_query($db,'SET NAMES utf8'); 
	mysqli_query($db,'SET COLLATION_CONNECTION=utf8_bin');
	global $db;
	
	
	$domain = 'http://'.$_SERVER['SERVER_NAME'];
	$hash = $_SESSION['hash'];
	$login = $_SESSION['login'];
	$user_id = $_SESSION['user_id'];
	$rang = $_SESSION['rang'];
	
	$token = '394618761:AAEnMKw0lDnXBsShw6MbXQbMpVA2isfl2Og';
	$url = "https://api.telegram.org/bot".$token;
	$id_chat = 12345666; # Get id_chat - Send message bot -- @id_chatbot
?>