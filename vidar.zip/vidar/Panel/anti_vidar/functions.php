<?php
	include('db.php');

	
	function auth($login,$pass)
	{
		global $db;
		$pass = md5($pass);
		$s = "SELECT `id`,`rang` FROM `Accounts` WHERE `Email` = '$login' AND `Password` = '$pass'";
		$r = mysqli_query($db,$s);
		$ok = mysqli_fetch_assoc($r);
		if($ok['id']>0)
		{  
			$_SESSION['hash'] = $pass;
			$_SESSION['login'] = $login;
			$_SESSION['user_id'] = $ok['id'];
			$_SESSION['rang'] = $ok['rang'];
			return true;
		}else { return false; }
		
	}
	
	function change_auth($login,$hash)
	{
		global $db;
		$s = "SELECT `id` FROM `Accounts` WHERE `Email` = '$login' AND `Password` = '$hash'";
		$r = mysqli_query($db,$s);
		$ok = mysqli_fetch_assoc($r);
		if($ok['id']>0)
		{  
			return true;
		}else { return false; }		
	}
	
	
	function get_colomn_val($table,$col,$id)
	{
		global $db;
		$s = "SELECT `$col` FROM `$table` WHERE `id` = '$id'";
		$r = mysqli_query($db,$s);
		$ok = mysqli_fetch_assoc($r);
		return $ok[$col];
	}
	
	function add_news($title,$text)
	{
		global $db;
		$date = time();
		$s = "INSERT INTO `news` (`title`,`text`,`date`) VALUES ('$title','$text','$date')";
		mysqli_query($db,$s);
		
	}
	
	
	
	function get_filesize($file)
	{
		if(!file_exists($file)) return "Файл  не найден";

	  $filesize = filesize($file);

	if($filesize > 1024){
	$filesize = ($filesize/1024);
		if($filesize > 1024){
		$filesize = ($filesize/1024);
			if($filesize > 1024) {
			$filesize = ($filesize/1024);
			$filesize = round($filesize, 1);
			return $filesize." ГБ";       
			} else {
			$filesize = round($filesize, 1);
			return $filesize." MБ";   
			}       
		} else {
		$filesize = round($filesize, 1);
		return $filesize." Кб";   
		}  
		} else {
		$filesize = round($filesize, 1);
		return $filesize." байт";   
		}
	}
?>