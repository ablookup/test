<?php
	$act = strip_tags($_GET['act']);
	
	
	if($act == '11')
	{
		echo "1,1,1,1,1,1,1,1,0,1,250,none;";
	}

?>